// Edit this list to publish your own mods. Replace each demo downloadUrl with a real link.
// Keep large ZIP files on a file host; Cloudflare Pages limits each site asset to 25 MiB.
window.NIGHTSHIFT_MODS = [
  {id:1,title:"Street Legend Coupe",category:"Cars",type:"FREE",price:"FREE",version:"1.0",description:"A fictional showcase vehicle entry. Replace this with your own mod description.",downloadUrl:"#",code:"SL"},
  {id:2,title:"Midnight Visual Pack",category:"Graphics",type:"PREMIUM",price:"PAID",version:"2.1",description:"A sample graphics listing. Add installation notes and compatibility details.",downloadUrl:"#",code:"MV"},
  {id:3,title:"Coastal Highway Expansion",category:"Maps",type:"FREE",price:"FREE",version:"1.2",description:"A sample map listing for your marketplace homepage.",downloadUrl:"#",code:"CH"},
  {id:4,title:"Advanced Garage System",category:"Scripts",type:"PREMIUM",price:"PAID",version:"1.4",description:"A sample gameplay script listing. Replace with your own release information.",downloadUrl:"#",code:"AG"},
  {id:5,title:"Urban Performance Sedan",category:"Cars",type:"FREE",price:"FREE",version:"1.0",description:"A sample car listing. Include game version and required dependencies.",downloadUrl:"#",code:"UP"},
  {id:6,title:"Desert Lighting Overhaul",category:"Graphics",type:"FREE",price:"FREE",version:"1.3",description:"A sample visual mod listing with a short description.",downloadUrl:"#",code:"DL"}
];