(() => {
  const mods = window.NIGHTSHIFT_MODS || [];
  const grid = document.getElementById("modGrid");
  const search = document.getElementById("searchInput");
  const count = document.getElementById("resultCount");
  const empty = document.getElementById("emptyState");
  const dialog = document.getElementById("modDialog");
  const dialogContent = document.getElementById("dialogContent");
  let active = "All";
  const safe = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  function render(){
    const q = search.value.trim().toLowerCase();
    const shown = mods.filter(m => (active === "All" || m.category === active) && (m.title+" "+m.category+" "+m.description).toLowerCase().includes(q));
    count.textContent = `${shown.length} MOD${shown.length===1?"":"S"}`;
    empty.classList.toggle("hidden", shown.length > 0);
    grid.innerHTML = shown.map(m => `<article class="mod-card">
      <div class="mod-thumb"><span class="tag">${safe(m.category.toUpperCase())}</span><span class="price">${safe(m.price)}</span><span class="thumb-code">${safe(m.code || "NS")}</span></div>
      <div class="mod-info"><div class="mod-meta"><span>NIGHTSHIFT DROP</span><span>V${safe(m.version)}</span></div>
      <h3>${safe(m.title)}</h3><p>${safe(m.description)}</p>
      <div class="card-bottom"><span class="version">${safe(m.type)} RELEASE</span><button class="details-btn" data-id="${m.id}">VIEW DETAILS ↗</button></div></div>
    </article>`).join("");
  }
  document.querySelectorAll("[data-filter]").forEach(btn => btn.addEventListener("click", () => {
    active = btn.dataset.filter;
    document.querySelectorAll(".filter").forEach(b => b.classList.toggle("active", b.dataset.filter === active));
    render();
    document.getElementById("mods").scrollIntoView({behavior:"smooth"});
  }));
  search.addEventListener("input", render);
  grid.addEventListener("click", e => {
    const btn = e.target.closest("[data-id]");
    if(!btn) return;
    const m = mods.find(x => String(x.id) === btn.dataset.id);
    if(!m) return;
    dialogContent.innerHTML = `<div class="eyebrow">${safe(m.category.toUpperCase())} / VERSION ${safe(m.version)}</div><h2>${safe(m.title)}</h2><p>${safe(m.description)}</p><p><b>Release:</b> ${safe(m.type)} &nbsp; <b>Price:</b> ${safe(m.price)}</p><a class="dialog-download" href="${safe(m.downloadUrl)}" target="_blank" rel="noopener">DOWNLOAD / GET MOD ↗</a><p>Only download mods from sources you trust. Follow the creator's installation instructions.</p>`;
    dialog.showModal();
  });
  document.getElementById("closeDialog").addEventListener("click", () => dialog.close());
  dialog.addEventListener("click", e => { if(e.target === dialog) dialog.close(); });
  document.getElementById("year").textContent = new Date().getFullYear();
  render();
})();