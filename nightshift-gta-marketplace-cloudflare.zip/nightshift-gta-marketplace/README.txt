NIGHTSHIFT GTA V MARKETPLACE — CLOUDFLARE PAGES STARTER

WHAT'S INCLUDED
- Responsive dark gaming marketplace homepage
- Search and category filters
- Featured mod cards and detail popups
- Free/paid labels
- Sample demo entries you can replace

EDIT YOUR MOD LISTINGS
1. Open mods.js.
2. Replace the sample entries with your real mod title, category, version and description.
3. Replace downloadUrl "#" with your real download URL.
4. Set price to "FREE" or your chosen price label.
5. Save and upload the updated files to GitHub; Cloudflare redeploys automatically.

CLOUDFLARE PAGES DEPLOYMENT (GITHUB METHOD)
1. Create/sign in to GitHub and make a new repository named nightshift-gta-marketplace.
2. Upload all files from this folder to the repository root (index.html, style.css, mods.js, app.js).
3. Sign in at https://dash.cloudflare.com/
4. Open Workers & Pages > Create application > Pages > Connect to Git.
5. Connect GitHub and choose your repository.
6. For a plain HTML site, leave Build command blank. Set Build output directory to / (repository root) if the dashboard requests it.
7. Click Save and Deploy. Your site will get a *.pages.dev address.

IMPORTANT LIMITS / NOTES
- Cloudflare Pages Free has a 25 MiB maximum per individual site asset. Do not put large GTA ZIP files in this site.
- Store mod archives on a suitable file host (or Cloudflare R2 after checking its current pricing/limits) and put the public download URL in mods.js.
- This is a static front-end starter, not a secure admin panel, database, payment processor, or automatic seller upload system.
- For paid mods, use a secure payment/fulfilment provider or manual payment verification before giving access. Never put private keys or payment credentials in client-side files.
- Change YOUR-EMAIL@example.com in index.html to your submission email.
- Replace the abstract artwork with screenshots you own or have permission to use.
- Use only mods and images you have permission to distribute. This is an independent fan site and is not affiliated with Rockstar Games.
